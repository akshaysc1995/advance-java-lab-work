package com.empServlet;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdac.dao.EmployeeDao;
import com.cdac.entity.Employee1;


public class EmployeeSevlet extends HttpServlet {
	

	
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Employee1 empo =new Employee1();
		empo.setEmpno(Integer.parseInt(request.getParameter("Empno")));
		empo.setName(request.getParameter("Empname"));
		empo.setSalary(Double.parseDouble(request.getParameter("salary")));
		empo.setDateOfJoin(LocalDate.parse(request.getParameter("date_of_join")));
		
		EmployeeDao emd =new EmployeeDao();
		emd.add(empo);
		
	}

}
