package com.cdac.app;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.component.CarPart;
import com.cdac.component.CarPartsInventory;




public class App {

	public static void main(String[] args) {
		//Loading spring/IOC container
		ApplicationContext ctx=new ClassPathXmlApplicationContext("my-spring-config.xml");
//	   
	    CarPartsInventory inv = (CarPartsInventory) ctx.getBean("carParts3");
		
//		CarPart cp = new CarPart();
//		cp.setPartName("mirror");
//		cp.setCarModel("Maruti 800");
//		cp.setPrice(1200);
//		cp.setQuantity(195);
		
//		//long ms1=System.currentTimeMillis();
//		inv.addNewPart(cp);
//		//long ms2=System.currentTimeMillis();
//		//System.out.println("Approx time taken :"+ (ms2-ms1 )+ " ms approx");
//		
		List<CarPart> list =inv.getAvailableParts();
		for(CarPart carPart:list)
			System.out.println(carPart);
		}
}
