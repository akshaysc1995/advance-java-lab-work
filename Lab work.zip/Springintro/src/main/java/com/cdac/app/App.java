package com.cdac.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.bank.Atm;
import com.cdac.component.Calculator;
import com.cdac.component.Car;
import com.cdac.component.CurrencyConverter;
import com.cdac.component.HelloWorld;
import com.cdac.component.LoginService;
import com.cdac.component.TextEditor;

public class App {

	public static void main(String[] args) {
		//Loading spring/IOC container
		ApplicationContext ctx=new ClassPathXmlApplicationContext("my-spring-config.xml");
	    //Accessing a perticular bean
		HelloWorld hw =(HelloWorld) ctx.getBean("hello");
		System.out.println(hw.sayhello(" Chorge"));
		//But why are we using Spring to create object of HelloWorld class?
		//we could have created object on our own like this:
		//HelloWorld hw =new HelloWorld();
		Calculator cl=(Calculator) ctx.getBean("calc");
		System.out.println(cl.add(10, 20));
		System.out.println(cl.sub(10, 20));
		
		CurrencyConverter cc=(CurrencyConverter) ctx.getBean("currencyConv");
		System.out.println(cc.convert("USD", "INR", 650));
		
		LoginService ls=(LoginService) ctx.getBean("login");
		System.out.println(ls.isValidUser("akshay", "3834"));
		
		TextEditor te=(TextEditor) ctx.getBean("textedt");
		te.load(" abd.txt");
		
		Car ce=(Car) ctx.getBean("car");
		ce.drive();
		
		Atm atm=(Atm) ctx.getBean("hdfcatmv2");
		atm.withdraw(10101010, 5000);
		
		}
}
