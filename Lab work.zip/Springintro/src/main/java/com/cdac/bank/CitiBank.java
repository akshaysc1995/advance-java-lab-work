package com.cdac.bank;

import org.springframework.stereotype.Component;

@Component("citibankv2")
public class CitiBank implements Bank {

	public boolean isAccountPresent(int acno) {
		if (acno==10101010)
			return true;
		return false;
	}
	public void withdraw(int atamId,int acno,double amount) {
		System.out.println("customer wants to withdraw money from citibank");
	}
}
