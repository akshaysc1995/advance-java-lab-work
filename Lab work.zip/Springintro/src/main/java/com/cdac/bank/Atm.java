package com.cdac.bank;

public interface Atm {

	public void withdraw(int acno,double amount);
}
