package com.cdac.component;

import org.springframework.stereotype.Component;

@Component("login")
public class LoginService {

		public boolean isValidUser(String username,String password) {
			if(username.equals("akshay")&& password.equals("1234"))
				return true;
			return false;
		}
	
}
