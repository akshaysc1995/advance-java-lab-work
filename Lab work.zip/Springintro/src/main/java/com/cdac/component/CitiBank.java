package com.cdac.component;

import org.springframework.stereotype.Component;

@Component
public class CitiBank implements Bank {

	public void withdraw(int atamId,int acno,double amount) {
		System.out.println("customer wants to withdraw money");
	}
}
