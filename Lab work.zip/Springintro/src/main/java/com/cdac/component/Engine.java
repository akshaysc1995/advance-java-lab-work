package com.cdac.component;

import org.springframework.stereotype.Component;

@Component("engine")
public class Engine {

	public void on() {
		System.out.println("broom broom");
		
	}
	
	public void off() {
		System.out.println("phoss phoss");
	}
}
