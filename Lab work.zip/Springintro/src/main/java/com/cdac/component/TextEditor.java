package com.cdac.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("textedt")
public class TextEditor {

	@Autowired //DI
	private SpellChecker sp;
	
	public void load(String document) {
		System.out.println("some code here for loading"+document);
		
		sp.checkSpellingMistakes(document);
	}
}
