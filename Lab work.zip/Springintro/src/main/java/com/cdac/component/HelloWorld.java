package com.cdac.component;

public class HelloWorld {

	public String sayhello(String name) {
		return "Hello"+ name;
	}
}
