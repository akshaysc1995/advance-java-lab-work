package com.cdac.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Ass1")
public class Assignment1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int number1=Integer.parseInt(request.getParameter("number1"));
		int number2=Integer.parseInt(request.getParameter("number2"));
		
		PrintWriter out = response.getWriter();
		
		 if(request.getParameter("add")!=null) {
			 int sum=number1+number2;
			 out.write("<html><body>");
			 out.write("<h1>"+sum+"<h1>");
			 out.write("</body></html>");
		 }
		 if(request.getParameter("sub")!=null) {
		   int divs=number1-number2;
		   out.write("<html><body>");
		   out.write("<h1>"+divs+"<h1>");
		   out.write("</body></html>");
		 }
	}

}
