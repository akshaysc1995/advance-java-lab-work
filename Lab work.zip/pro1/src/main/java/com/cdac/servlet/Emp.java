package com.cdac.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Emp
 */
@WebServlet("/Emp.cdac")
public class Emp extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cdac", "Akshay", "akshay123");
			
			
				PreparedStatement st = conn.prepareStatement("insert into empl(name, email) values(?, ? )");
				
				
				st.setString(1,name); //substituting ? with actual value
				st.setString(2, email);
				st.executeUpdate();
				conn.close();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			
			PrintWriter out = response.getWriter();
			out.write("<html><body>");
			out.write("<h1>Registration successful!</h1>");
			out.write("</body></html>");
	}

}
