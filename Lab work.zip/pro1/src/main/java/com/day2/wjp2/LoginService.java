package com.day2.wjp2;

public class LoginService {

	public boolean loginCheck(String username, String password) {
           if(username.equals("akshay")&& password.equals("123"))
                return true;
           return false;
	}

}
