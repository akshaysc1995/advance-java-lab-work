package com.cdac.component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("carparts2")
public class CarPartsInventoryImpl2 implements CarPartsInventory{
	
	@Autowired
	private DataSource dataSource;
	
	public void addNewPart(CarPart carpart) {
		Connection conn = null;
		try {
			

			long ms1 = System.currentTimeMillis();
			conn =dataSource.getConnection(); 
			long ms2 = System.currentTimeMillis();
			System.out.println("Approx time taken to obtain a  connect from the pool : " + (ms2 - ms1) + " ms");
	
			PreparedStatement st = conn.prepareStatement("insert into carpart(part_name, car_model, price, quantity) values(?, ?, ?, ?)");
			st.setString(1, carpart.getPartName());
			st.setString(2, carpart.getCarModel());
			st.setDouble(3, carpart.getPrice());
			st.setInt(4, carpart.getQuantity());
			st.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			try { conn.close(); } catch(Exception e) { }
		}				
	}

	public List<CarPart> getAvailableParts(){
		Connection conn=null;
		try {
			conn=dataSource.getConnection();
			PreparedStatement st=conn.prepareStatement("select * from carpart");
			ResultSet rs=st.executeQuery();
			 
			List<CarPart> list=new ArrayList<>();
			while(rs.next()) {
				CarPart carpart=new CarPart();
				carpart.setPartNo(rs.getInt(1));
				carpart.setPartName(rs.getString(2));
				carpart.setCarModel(rs.getString(3));
				carpart.setPrice(rs.getDouble(4));
				carpart.setQuantity(rs.getInt(5));
				list.add(carpart);
			}
			return list;
		}
		catch(SQLException e) {
			e.printStackTrace();
			return null;
		}
		finally {
			try {conn.close();} catch(Exception e) { } 
		
	}
}
}
