package com.cdac.component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Component;

@Component("carparts")
public class CarPartsInventoryImpl1 implements CarPartsInventory{
	public void addNewPart(CarPart carpart) {
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			//long ms1 = System.currentTimeMillis();
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cdac", "Akshay", "akshay123");
			//long ms2 = System.currentTimeMillis();
			//System.out.println("Approx time taken to connect : " + (ms2 - ms1) + " ms");
	
			PreparedStatement st = conn.prepareStatement("insert into carpart(part_name, car_model, price, quantity) values(?, ?, ?, ?)");
			st.setString(1, carpart.getPartName());
			st.setString(2, carpart.getCarModel());
			st.setDouble(3, carpart.getPrice());
			st.setInt(4, carpart.getQuantity());
			st.executeUpdate();
		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		finally {
			try { conn.close(); } catch(Exception e) { }
		}				
	}

	public List<CarPart> getAvailableParts(){
		return null;
	}
}
