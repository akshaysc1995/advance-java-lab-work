package com.cdac.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdac.dao.CustomerAddressDao;
import com.cdac.entity.Address;
import com.cdac.entity.Customer;



public class CustomerAddressServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		CustomerAddressDao dao = new CustomerAddressDao();

		Customer cust = new Customer();
		cust.setName(request.getParameter("name"));
		cust.setEmail(request.getParameter("email"));
		
		Address addr =new Address();
		addr.setCity(request.getParameter("city"));
		addr.setPincode(Integer.parseInt(request.getParameter("pin")));
		addr.setState(request.getParameter("state"));
		
		cust.setAddress(addr);
		dao.add(cust);
		
		PrintWriter out=response.getWriter();
		out.write("<h1>added successfully</h1>");
		
	}

}
