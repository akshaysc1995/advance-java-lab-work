package com.cdac.app;

import java.time.LocalDate;
import java.util.List;

import com.cdac.dao.DepartmentEmployeeDao;
import com.cdac.dao.GenericDao;
import com.cdac.entity.Department;
import com.cdac.entity.Employee;

public class DepartmentEmployeeExample {

	public static void main(String[] args) {
		
		//GenericDao dao=new GenericDao();
		
		DepartmentEmployeeDao dao=new DepartmentEmployeeDao();
		
//		Department department=new Department();
//		
//		department.setName("research");
//		department.setLocation("dadar");
//		
//		dao.save(department);
		
//		Department department=(Department) dao.fetchById(Department.class, 4);
//		
//		Employee employee=new Employee();
//		employee.setEmpno(1007);
//		employee.setName("Anuj");
//		employee.setSalary(65000);
//		employee.setDateOfJoining(LocalDate.of(2020,11,30));
//		
//		employee.setDepartment(department);
//		dao.save(employee);
		
//		List<Employee>employees=dao.fetchSalaryByName("Anuj");
//		for(Employee employee:employees)
//			System.out.println(employee.getSalary()+" "+employee.getDateOfJoining());
//		
		dao.delete(Employee.class, 1005);
		
	}
}
