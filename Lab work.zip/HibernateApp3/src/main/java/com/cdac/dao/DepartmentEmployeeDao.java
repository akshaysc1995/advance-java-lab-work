package com.cdac.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cdac.entity.Employee;
import com.cdac.entity.Song;

public class DepartmentEmployeeDao extends GenericDao {


	public List<Employee> fetchSalaryByName(String name) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		try {
			EntityManager em = emf.createEntityManager();
			Query q = em.createQuery("select s from Employee s where s.name = :na");
			q.setParameter("na", name);
			List<Employee> list = q.getResultList();
			return list;
		}
		finally {
			emf.close();
		}
	}
}
