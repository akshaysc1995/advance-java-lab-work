package com.cdac.app;

import java.util.ArrayList;
import java.util.List;

import com.cdac.dao.GenericDao;
import com.cdac.entity.Author;
import com.cdac.entity.Book;

public class BookAuthorExample {

	public static void main(String[] args) {
		//adding few authors
		GenericDao dao=new GenericDao();
	
//		Author author=new Author();
//		author.setName("Eric Freeman");
//		author.setEmail("eric@gmail.com");
//		dao.save(author);
		
		
		//adding book along with the author deatils
//		Book book=new Book();
//		book.setName("Head First Design patterns");
//		book.setCost(2500);
//		
//
//		List<Author> authors = new ArrayList<>();
//		authors.add((Author) dao.fetchById(Author.class, 1));
//		authors.add((Author) dao.fetchById(Author.class, 2));
//		
//		book.setAuthors(authors);
//		dao.save(book);
		
//		Book book=new Book();
//		book.setName("book by javaScript");
//		book.setCost(1500);
//		dao.save(book);
		
//		Book book=(Book) dao.fetchById(Book.class, 2);
//		List<Author> authors = new ArrayList<>();
//		authors.add((Author) dao.fetchById(Author.class, 1));
//		authors.add((Author) dao.fetchById(Author.class, 2));
//		
//		book.setAuthors(authors);
//		
//		dao.save(book);
		
		Book book=new Book();
		book.setName("Poor dad rich dad");
		book.setCost(4000);
		
		Author author1=new Author();
		author1.setName("john wick");
		author1.setEmail("johnw@gmail.com");
		
		Author author2=new Author();
		author2.setName("ronaldo francis");
		author2.setEmail("ronaldo@gmail.com");
		
		List<Author>list=new ArrayList<Author>();
		list.add(author1);
		list.add(author2);
		
		book.setAuthors(list);
		
		dao.save(book);
		
	}
}
