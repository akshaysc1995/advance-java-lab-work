package com.cdac.entity;

import java.util.List;

import com.cdac.dao.CustomerAddressDao;

public class AddCustomerAndAddress {

	public static void main(String[] args) {
		CustomerAddressDao dao = new CustomerAddressDao();

		/*
		 * Customer c = new Customer(); c.setName("Majrul"); c.setEmail("majrul@gmail");
		 * dao.add(c);
		 * 
		 * Address a = new Address(); a.setPincode(400001); a.setCity("Mumbai");
		 * a.setState("Maharashtra"); dao.add(a);
		 */

		/*
		 * Customer c1 = dao.fetchCustomer(3); Address a1 = dao.fetchAddress(3);
		 * 
		 * 
		 * c1.setAddress(a1); dao.update(c1);
		 */
		/*
		 * Customer c = new Customer(); c.setName("vikram"); c.setEmail("vikram@gmail");
		 * 
		 * 
		 * Address a = new Address(); a.setPincode(411003); a.setCity("pune");
		 * a.setState("Maharashtra"); dao.add(a);
		 * 
		 * c.setAddress(a); dao.add(c);
		 */
		/*
		 * Customer c = new Customer(); c.setName("soham"); c.setEmail("soham@outlook");
		 * 
		 * 
		 * Address a = new Address(); a.setPincode(411043); a.setCity("bhor");
		 * a.setState("Maharashtra");
		 * 
		 * 
		 * c.setAddress(a);
		 *  dao.add(c);
		 */

		/*
		 * List<Customer>list =dao.fetchCustomersByEmail("gmail"); for(Customer c :list)
		 * System.out.println(c.getName()+" "+c.getEmail()+" "+c.getAddress()+" "+c.
		 * getId());
		 */

		/*
		 * Customer c = new Customer(); c.setName("Mohini");
		 * c.setEmail("mohini@outlook");
		 * 
		 * Address a = new Address(); a.setPincode(411027); a.setCity("Pune");
		 * a.setState("Maharashtra");
		 * 
		 * c.setAddress(a);
		 * 
		 * dao.add(c);
		 */

		// List<Customer> list = dao.fetchCustomersByEmail("outlook");

		List<Customer> list = dao.fetchCustomersByCity("Pune");
		for (Customer c : list)
			System.out.println(c.getId() + " " + c.getName() + " " + c.getEmail());

		
		  
		 Address a = dao.fetchAddressByCustomerName("soham");
		  System.out.println(a.getId() + " " + a.getCity() + " " + a.getPincode() + " "
		  + a.getState());
		

	}
}
